-- MariaDB dump 10.19  Distrib 10.5.22-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: asterisk
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
DROP TABLE IF EXISTS `devices`;
CREATE TABLE `devices` (
  `id` varchar(20) NOT NULL DEFAULT '',
  `tech` varchar(10) NOT NULL DEFAULT '',
  `dial` varchar(255) NOT NULL DEFAULT '',
  `devicetype` varchar(5) NOT NULL DEFAULT '',
  `user` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `emergency_cid` varchar(100) DEFAULT NULL,
  `hint_override` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tech` (`tech`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES ('100','pjsip','PJSIP/100','fixed','100','Front Desk','',NULL),('101','pjsip','PJSIP/101','fixed','101','Dana Ortiz','',NULL),('102','iax2','IAX2/102','fixed','102','Sam Lee','',NULL);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sip`;
CREATE TABLE `sip` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL,
  `flags` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
LOCK TABLES `sip` WRITE;
INSERT INTO `sip` VALUES ('100','account','100',40),('100','callerid','Front Desk <100>',41),('100','secret','e1f2a3b4c5d6e7f8a9b0',2),('100','media_encryption','sdes',30),('101','secret','short',2),('101','callerid','Dana \'D\' Ortiz <101>',41),('tr-peer-2','host','old.carrier.example',3),('tr-peer-2','username','oldacct',4),('tr-peer-2','secret','old-carrier-secret',5),('tr-peer-2','fromdomain','old.carrier.example',6),('tr-reg-2','register','oldacct:old-carrier-secret@old.carrier.example',0);
UNLOCK TABLES;
DROP TABLE IF EXISTS `dahdi`;
CREATE TABLE `dahdi` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL DEFAULT '',
  `flags` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB;
-- Dump completed on 2026-10-01 10:00:00
